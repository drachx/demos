import React from "react";

import { ApolloClient, InMemoryCache, useQuery, gql } from "@apollo/client";
import { ApolloProvider } from "@apollo/client/react";

export default function Weather() {
    const client = new ApolloClient({
        uri: "https://graphql-weather-api.herokuapp.com/",
        cache: new InMemoryCache(),
    });

    const QUERY = gql`
        {
            getCityByName(name: "Auckland") {
                id
                name
                country
                weather {
                    summary {
                        title
                        description
                        icon
                    }
                }
            }
        }
    `;

    function Output() {
        const { loading, error, data } = useQuery(QUERY);

        if (loading) return <p>Loading...</p>;
        if (error) return <p>Error :(</p>;
        const weather = {
            city: data.getCityByName.name,
            country: data.getCityByName.country,
            summary: data.getCityByName.weather.summary,
        };
        const weatherIcon = `http://openweathermap.org/img/w/${weather.summary.icon}.png`;

        return (
            <div className="card">
                <h2>
                    Weather in {weather.city}({weather.country})
                </h2>
                <div>
                    <img className="smaller" src={weatherIcon}></img>
                    <div>
                        {weather.summary.title} ({weather.summary.description})
                    </div>
                </div>
            </div>
        );
    }

    return (
        <ApolloProvider client={client}>
            <h2>Weather results</h2>
            <div className="grid">
                <Output></Output>
            </div>
        </ApolloProvider>
    );
}
