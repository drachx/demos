import React from "react";

import { ApolloClient, InMemoryCache, useQuery, gql } from "@apollo/client";
import { ApolloProvider } from "@apollo/client/react";

export default function Anilist() {
    const client = new ApolloClient({
        uri: "https://graphql.anilist.co",
        cache: new InMemoryCache(),
    });

    const QUERY = gql`
        {
            Page {
                media {
                    title {
                        english
                    }
                    description
                    coverImage {
                        large
                        medium
                        color
                    }
                }
            }
        }
    `;

    function Output() {
        const { loading, error, data } = useQuery(QUERY);

        if (loading) return <p>Loading...</p>;
        if (error) return <p>Error :(</p>;

        const media = data.Page.media;

        return media.map((data) => (
            <div className="card">
                <h2>{data.title.english}</h2>
                <img src={data.coverImage.large}></img>
                <p dangerouslySetInnerHTML={{ __html: data.description }}></p>
            </div>
        ));
    }

    return (
        <ApolloProvider client={client}>
            <h2>Anilist results</h2>
            <div className="grid">
                <Output></Output>
            </div>
        </ApolloProvider>
    );
}
