import React from "react";

import { ApolloClient, InMemoryCache, useQuery, gql } from "@apollo/client";
import { ApolloProvider } from "@apollo/client/react";

export default function Music() {
    const client = new ApolloClient({
        uri: "https://graphbrainz.herokuapp.com/",
        cache: new InMemoryCache(),
    });

    const QUERY = gql`
        {
            search {
                releaseGroups(query: "Christmas") {
                    results: edges {
                        releaseGroup: node {
                            title
                            fanArt {
                                albumCovers {
                                    url
                                }
                            }
                        }
                    }
                }
            }
        }
    `;

    function Output() {
        const { loading, error, data } = useQuery(QUERY);

        if (loading) return <p>Loading...</p>;
        if (error) return <p>Error :(</p>;

        const media = data.search.releaseGroups.results.filter(
            (data) =>
                !!data.releaseGroup.fanArt &&
                !!data.releaseGroup.fanArt.albumCovers &&
                data.releaseGroup.fanArt.albumCovers.length > 0
        );

        return media.map((data) => (
            <div className="card">
                <h2>{data.releaseGroup.title}</h2>
                <img src={data.releaseGroup.fanArt.albumCovers[0].url} />
            </div>
        ));
    }

    return (
        <ApolloProvider client={client}>
            <h2>Music results</h2>
            <div className="grid">
                <Output></Output>
            </div>
        </ApolloProvider>
    );
}
