import React from "react";

import Music from "./pages/music";
import Anilist from "./pages/anilist";
import Weather from "./pages/weather";

export default function App() {
    return (
        <div>
            <h1>RAG - React Apollo GraphQL</h1>
            <Weather></Weather>
            <Music></Music>
            <Anilist></Anilist>
        </div>
    );
}
